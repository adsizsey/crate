**WARNING: THIS PROJECT IS IN MAINTENANCE MODE, DUE TO INSUFFICIENT MAINTAINER RESOURCES**

It works fine, but will generally no longer be improved.

We are currently only accepting changes which:

* keep this compiling with the latest versions of Rust or its dependencies.
* have minimal review requirements, such as documentation changes (so not totally new APIs).

------

A Set of bits.

Documentation is available at https://contain-rs.github.io/bit-set/bit_set.

[![Build Status](https://travis-ci.org/contain-rs/bit-set.svg?branch=master)](https://travis-ci.org/contain-rs/bit-set)
[![crates.io](http://meritbadge.herokuapp.com/bit-set)](https://crates.io/crates/bit-set)
